local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

-- ==========================================
-- HỆ THỐNG AUTO PICKUP
-- ==========================================
local Rarities = { "Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythical", "Divine", "Secret" }
local StatOptions = { 
    "Crit Chance", "Crit Damage", "Damage", 
    "DamageReduction", "Mana Regen", "ManaCostReduction", "Gold Bonus", "Luck", 
    "Health", "ReflectDamage", "Slash", "Immunity"
}
local SkillDropOptions = {
    "Prime Ice Sword", "Prime Ice Sword V2", "Prime Ice Sword V3", "Stamp on Ice", "Ice Sword", "Ice Magical",
    "Fairy", "Fairy Staff", "Fairy Sword",
    "Star Fire", "Fire Ball", "Fire Sword", "Fire Slash", "Fire Arrow", "Tornado Fire", "Fire Hole",
    "Water Ball", "Whirl Pool", "Water Beam", "Water Hole",
    "Lighting Staff", "Summon", "Meteo", "Light Health", "Light Zone", "Light Sword", "Murasaki", "Ultrasound",
    "Pistol", "Rock Dragon", "Wall", "Immunity", "Health", "Slash", "Tornado",
    "Ultra Black Hole", "Ultra Fire Hole"
}
local RingOptions = { 
    "Ring Water", "Ring Nature", "Ring Fire", "Ring Ice", "Ring Shadow", "Ring Angel", "Ring Fairy" 
}

local DropConfig = {
    Enabled = false,
    TeleportEnabled = true,
    Radius = 250,
    StatMinValues = {}
}

for _, stat in ipairs(StatOptions) do DropConfig.StatMinValues[stat] = 0 end

local function passesDropFilter(model, prompt)
    if not model then return false end

    local rawSkills = (Fluent.Options.SelectSkills and Fluent.Options.SelectSkills.Value) or {}
    local rawRings = (Fluent.Options.SelectRings and Fluent.Options.SelectRings.Value) or {}
    local rawRingRarities = (Fluent.Options.SelectRingRarity and Fluent.Options.SelectRingRarity.Value) or {}
    local rawRarities = (Fluent.Options.SelectRarity and Fluent.Options.SelectRarity.Value) or {}
    local rawStats = (Fluent.Options.SelectStats and Fluent.Options.SelectStats.Value) or {}

    local activeSkills, activeRings, activeRingRarities, activeRarities, activeStats = {}, {}, {}, {}, {}

    for name, enabled in pairs(rawSkills) do if enabled == true then table.insert(activeSkills, string.lower(name)) end end
    for name, enabled in pairs(rawRings) do if enabled == true then table.insert(activeRings, string.lower(name)) end end
    for name, enabled in pairs(rawRingRarities) do if enabled == true then table.insert(activeRingRarities, string.lower(name)) end end
    for name, enabled in pairs(rawRarities) do if enabled == true then table.insert(activeRarities, string.lower(name)) end end
    for name, enabled in pairs(rawStats) do if enabled == true then table.insert(activeStats, name) end end

    local itemTier = tostring(model:GetAttribute("ItemTier") or (model.Parent and model.Parent:GetAttribute("ItemTier")) or ""):lower()
    local enchantName = tostring(model:GetAttribute("EnchantName") or (model.Parent and model.Parent:GetAttribute("EnchantName")) or ""):lower()
    local enchantVal = tonumber(model:GetAttribute("EnchantValue")) 
                     or tonumber(model:GetAttribute("EnchantBaseValue")) 
                     or (model.Parent and tonumber(model.Parent:GetAttribute("EnchantValue"))) or 0
    local skillId = tostring(model:GetAttribute("SkillId") or (model.Parent and model.Parent:GetAttribute("SkillId")) or ""):lower()
    local fullModelName = (model.Name .. " " .. (prompt and prompt.ObjectText or "")):lower()

    local isSkill = false
    if #activeSkills > 0 then
        for _, skillName in ipairs(activeSkills) do
            if skillId:find(skillName, 1, true) or fullModelName:find(skillName, 1, true) then
                return true
            end
        end
    end
    for _, skillName in ipairs(SkillDropOptions) do
        local lowerName = string.lower(skillName)
        if skillId:find(lowerName, 1, true) or fullModelName:find(lowerName, 1, true) then
            isSkill = true
            break
        end
    end
    if isSkill then return false end

    local isRing = fullModelName:find("ring", 1, true) or false
    if isRing then
        if #activeRings > 0 then
            local ringTypeMatch = false
            for _, ringName in ipairs(activeRings) do
                if fullModelName:find(ringName, 1, true) then
                    ringTypeMatch = true
                    break
                end
            end

            if ringTypeMatch then
                if #activeRingRarities > 0 then
                    for _, rName in ipairs(activeRingRarities) do
                        if itemTier == rName or fullModelName:find(rName, 1, true) then
                            return true
                        end
                    end
                    return false
                else
                    return true
                end
            end
        end
        return false
    end

    if #activeRarities == 0 and #activeStats == 0 then return false end

    local rarityMatch = false
    if #activeRarities > 0 then
        for _, rName in ipairs(activeRarities) do
            if itemTier == rName or fullModelName:find(rName, 1, true) then
                rarityMatch = true
                break
            end
        end
    else
        rarityMatch = true
    end

    local statMatch = false
    if #activeStats > 0 then
        for _, statName in ipairs(activeStats) do
            local cleanStat = string.lower(statName):gsub("%s+", "")
            local cleanEnchant = enchantName:gsub("%s+", "")

            if cleanEnchant == cleanStat or cleanEnchant:find(cleanStat, 1, true) or fullModelName:find(cleanStat, 1, true) then
                local minReq = DropConfig.StatMinValues[statName] or 0
                if enchantVal >= minReq then
                    statMatch = true
                    break
                end
            end
        end
    else
        statMatch = true
    end

    return rarityMatch and statMatch
end

local function triggerPrompt(prompt)
    if not prompt or not prompt.Parent then return end
    prompt.HoldDuration = 0
    prompt.RequiresLineOfSight = false
    prompt.MaxActivationDistance = math.huge
    prompt.Enabled = true

    if fireproximityprompt then fireproximityprompt(prompt) end

    pcall(function()
        if prompt.InputHoldBegin then
            prompt:InputHoldBegin()
            task.wait(0.05)
            prompt:InputHoldEnd()
        end
    end)
end

local isTeleportingToPick = false

task.spawn(function()
    while task.wait(0.1) do
        if DropConfig.Enabled and not isTeleportingToPick then
            local character = LocalPlayer and LocalPlayer.Character
            local hrp = character and character:FindFirstChild("HumanoidRootPart")

            if hrp then
                local itemDropFolder = workspace:FindFirstChild("itemdrop") or workspace
                for _, obj in pairs(itemDropFolder:GetDescendants()) do
                    if obj:IsA("ProximityPrompt") then
                        local itemModel = obj:FindFirstAncestorOfClass("Model") or obj.Parent
                        local targetPart = (obj.Parent and obj.Parent:IsA("BasePart") and obj.Parent) 
                                        or (itemModel and itemModel:FindFirstChildWhichIsA("BasePart", true))

                        if targetPart and (targetPart.Position - hrp.Position).Magnitude <= DropConfig.Radius then
                            local ok, filterResult = pcall(function()
                                return passesDropFilter(itemModel, obj)
                            end)
                            
                            if ok and filterResult == true then
                                isTeleportingToPick = true
                                local originalCFrame = hrp.CFrame

                                if DropConfig.TeleportEnabled then
                                    hrp.CFrame = targetPart.CFrame * CFrame.new(0, 1.5, 0)
                                    task.wait(0.1)

                                    local startTime = tick()
                                    while obj and obj.Parent and (tick() - startTime < 1.5) do
                                        triggerPrompt(obj)
                                        task.wait(0.1)
                                    end

                                    if LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart") then
                                        LocalPlayer.Character.HumanoidRootPart.CFrame = originalCFrame
                                    end
                                else
                                    triggerPrompt(obj)
                                end
                                
                                task.wait(0.1)
                                isTeleportingToPick = false
                                break
                            end
                        end
                    end
                end
            end
        end
    end
end)
